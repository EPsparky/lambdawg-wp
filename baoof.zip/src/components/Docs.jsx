import React from 'react';

const Docs = () => {

  return (
    <div>

      <h1>L A M B D A W G * D O C S</h1>

      <h2>What it do baby</h2>
      <p>It does some pretty sick shit, let me tell you all about it here.</p>

      <h2>Set up & Installation</h2>
      <p>Whew, its a doozy let me tell you.</p>

    </div>
  )
}

export default Docs;